
# coding: utf-8

# In[2]:


import numpy as np
from os import path as op
from sys import path as sp
module_path = op.abspath(op.join('..'))
if module_path not in sp:  # add local path to import helpers
    sp.append(module_path)
import pyfish as pf
from importlib import reload
import ipywidgets as widgets
pf = reload(pf)
import time
import datetime

print ('time', datetime.datetime.now())
# ## Get neurons and neuron-activity from lif stack (takes 15-20 minutes)

# In[4]:


pyfish = pf.Pyfish("./data/fish36_6dpf_medium.lif", use_gpu = True, thread_count=2)


# In[ ]:

#print (alignment_frame)

displacements,std_deviations, cell_positions, cell_sizes, cell_activities = pyfish.register_whole_stack()
#displacement = pyfish.register_chunk_wise(save_path="./data/fish37_6dpf_medium.h5")
#newframe = pyfish.register_frame_wise()
#pyfish.register_whole_stack(save_path="./data/fish37_6dpf_medium.h5")
#displacement = pyfish.register_whole_stack()

print ('time', datetime.datetime.now())
# ### save results

#np.save("./data/displacement32_no_upsample.npy", displacements)
#np.save("./data/cell_std_deviation.npy", std_deviations)
#np.save("./data/cell_positions.npy", cell_positions)
#np.save("./data/cell_sizes.npy", cell_sizes)
#np.save("./data/cell_activities.npy", cell_activities)


# ### load results

# In[ ]:


#std_deviations  = np.load("./data/cell_std_deviation.npy")
#cell_positions  = np.load("./data/cell_positions.npy")
#cell_sizes      = np.load("./data/cell_sizes.npy")
#cell_activities = np.load("./data/cell_activities.npy")


# ## Remove Cells by Hand
# ### show found cells

# In[ ]:


#def f(z=0): pf.show_inline_scatter_and_image(std_deviations[z], cell_positions[z], s=cell_sizes[z], vmax=100)
#widgets.interact(f, z=range(std_deviations.shape[0]))


# ### remove cells with their sizes and activities

# In[ ]:


# pyfish needs to be imported as "pf" for this to work
#def f(z=0): pf.remove_cells_by_hand(z, std_deviations, cell_positions, cell_sizes, cell_activities, (900,900), vmax=100, remove_border=10)
#widgets.interact(f, z=range(std_deviations.shape[0]))


# ## Calculate difference to standard cell activity (𐤃F/F)

# In[ ]:


#dffs = pf.get_dff(cell_activities, 20)

#def f(z=0): pf.show_inline_image(dffs[z], (20,10), vmax=2) 
#widgets.interact(f, z=range(len(dffs)))


# ## Visualize in 3D

# In[ ]:


#cell_info = pf.intensity_to_color_and_size(cell_positions, dffs, col_min="#ff0000", col_mid="#3333cc", col_max="#00ff00",
#                                           min_val=-1.0, mid_val=0.0, max_val=2.0, min_size=0.1, max_size=1)


# In[ ]:


#pf.show_inline_3D_scatter(cell_info, pyfish.read_frame(0), vol_max_val=150, speed=5, t_range=range(300,304))

